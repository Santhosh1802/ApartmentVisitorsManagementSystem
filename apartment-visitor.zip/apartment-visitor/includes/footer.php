<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.0
    </div>
    Copyright &copy; <?php echo date("Y");?> - Developed By <strong> Akilesh Kailash Santhosh </strong>
  </footer>